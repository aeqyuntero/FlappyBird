document.addEventListener('keydown', function(e){
  if(e.keyCode == 32){
    console.log("saltando");
  }
});


var ancho=831, alto=660;
var canvas, contexto;
var imgFondo, imgTuboA, imgTuboB, imgAveA, imgAveB, imgAveC;

function cargarImagenes(){
  imgFondo = new Image();
  imgFondo.src = 'mockups/fondo.png';
  imgTuboA = new Image();
  imgTuboA.src = 'mockups/tuberia.png';
  imgTuboB = new Image();
  imgTuboB.src = 'mockups/tuberiab.png';
  imgAveA = new Image();
  imgAveA.src = 'mockups/avev11.png';
  imgAveB = new Image();
  imgAveB.src = 'mockups/ave12.png';
  imgAveC = new Image();
  imgAveC.src = 'mockups/ave13.png';
}

function inicializar(){
  canvas = document.getElementById('canvas');
  contexto = canvas.getContext('2d');
  cargarImagenes();
}

function borrarCanvas(){
  canvas.width = ancho;
  canvas.height = alto;
}

function dibujarFondo(){
  contexto.drawImage(imgFondo,0,0,ancho,alto,0,0,ancho,alto);
}


//------------------------------------------------------------------------------
//bucle principal

var FPS = 50;
setInterval(function(){
  principal();
},1000/FPS);

function principal(){
  borrarCanvas();
  dibujarFondo();
}
