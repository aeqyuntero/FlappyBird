document.addEventListener('keydown', function(e){
  if(e.keyCode == 32){
    saltar();
  }
});


var ancho=831, alto=660;
var canvas, contexto;
var imgFondo, imgTuboA, imgTuboB, imgAveA, imgAveB, imgAveC;

function cargarImagenes(){
  imgFondo = new Image();
  imgFondo.src = 'mockups/fondo.png';
  imgTuboA = new Image();
  imgTuboA.src = 'mockups/tuberia.png';
  imgTuboB = new Image();
  imgTuboB.src = 'mockups/tuberiab.png';
  imgAveA = new Image();
  imgAveA.src = 'mockups/avev11.png';
  imgAveB = new Image();
  imgAveB.src = 'mockups/ave12.png';
  imgAveC = new Image();
  imgAveC.src = 'mockups/ave13.png';
}

function inicializar(){
  canvas = document.getElementById('canvas');
  contexto = canvas.getContext('2d');
  cargarImagenes();
}

function borrarCanvas(){
  canvas.width = ancho;
  canvas.height = alto;
}

function dibujarFondo(){
  contexto.drawImage(imgFondo,0,0,ancho,alto,0,0,ancho,alto);
}

var flappy = {y: 250, vy: 0, gravedad: 1, salto: 12, vymax: 9, saltando: false};

function dibujarFlappy(){
  contexto.drawImage(imgAveA,0,0,38,26,100,flappy.y,38,26);
}

function saltar(){
  flappy.saltando = true;
  flappy.vy = flappy.salto;
}

function gravedad(){
  if(flappy.saltando == true){
    if(flappy.y - flappy.vy - flappy.gravedad > 544){
      flappy.saltando = false;
      flappy.vy = 0;
      flappy.y = 544;
    }else{
      flappy.vy -= flappy.gravedad;
      flappy.y -= flappy.vy;
    }
  }
}


//------------------------------------------------------------------------------
//bucle principal

var FPS = 40;
setInterval(function(){
  principal();
},1000/FPS);

function principal(){
  borrarCanvas();
  gravedad();
  dibujarFondo();
  dibujarFlappy();
}
